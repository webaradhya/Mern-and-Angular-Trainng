console.log("Hi! Aradhya")
setTimeout(function cb(){
    console.log("Welcome to Blazeclan")
}, 0)
console.log("Have a Nice Day!!!")