console.log("Start")

setTimeout( function cb() {
    console.log("Callback")
}, 50000)

console.log("End")