function add(a,b){
    console.log(a+b) ;
    return a+b;
}

function average(a,b){
    console.log(add(a,b)/2);
}

average(4,4);