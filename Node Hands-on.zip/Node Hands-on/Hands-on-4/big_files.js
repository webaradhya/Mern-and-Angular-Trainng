// Import http and fs
const fs=require('fs')
const http = require( 'http')

// Creating Server
http.createServer((req, res) =>{

	// Reading file
	fs.readFile(`Hands-on-4\\http_server.js`, function (err,filedata) {
	if (err) {

		// Handling error
		res.writeHead(404);
		res.end(JSON.stringify(err));
		return;
	}

	// serving file to the server
	res.writeHead(200);
	res.end(filedata);
	});
}).listen(80,'localhost');
