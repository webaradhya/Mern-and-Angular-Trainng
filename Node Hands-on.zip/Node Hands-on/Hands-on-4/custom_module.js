var pi = Math.PI
exports.area = function (r) {
    var res = pi*r*r;
    res = res.toFixed(2);
    return res;
};

exports.perimeter = function(r) {
    var ans = 2*r*pi;
    ans = ans.toFixed(2);
    return ans;
}