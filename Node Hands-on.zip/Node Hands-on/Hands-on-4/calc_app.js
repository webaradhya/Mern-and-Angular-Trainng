var circle = require('./custom_module');
var r = 20;
console.log("Area of Circle : ",circle.area(r));
console.log("Circumference of Circle : ",circle.perimeter(r));