const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('Enter first name : ', (answer1) => {
    rl.question('Enter second name : ', (answer2) => {
        rl.question('Enter Age : ',(answer3) =>{
            rl.question('Enter Gender : ',(answer4) => {
                var fullname = answer1 + ' ' +answer2;
                console.log(`Full Name of Employee is : ${fullname}`);
                console.log(`Current Age of Employee is : ${answer3}`);
                console.log(`Age of Employee Next Year : ${answer3}`);
                console.log(`Gender of Employee : ${answer4}`);
                rl.close();
            });
        });
    });
});