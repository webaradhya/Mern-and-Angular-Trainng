import chalk from 'chalk';
console.log(chalk.green('Application Messages'));
console.log(chalk.red("Error!!!"));