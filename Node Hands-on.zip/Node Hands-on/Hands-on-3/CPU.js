var os = require('os');
console.log('Total Memory:',os.totalmem());
console.log('Free Memory:',os.freemem());
console.log('No. of CPU:',os.cpus());