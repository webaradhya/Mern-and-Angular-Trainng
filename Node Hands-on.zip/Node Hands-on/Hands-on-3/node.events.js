const events = require('events');
ee = new events.EventEmitter();

//Creating event Handlers
const openFile = () =>{
    console.log('1: Start a car');
}
const processFile = () => console.log("2: Select your Gear \n3: Release the Parking Brake\n4: Set the car in motion\n5: Use the Natural Gear\n6: Using Lower Gears");
const closeFile = () => console.log("7: Stop the Car");

//Register the event Handlers to the events
ee.on('open',openFile);
ee.on('process',processFile);
ee.on('close',closeFile);

console.log("How to drive a car step by step:");

//Trigger the events
ee.emit('open');
ee.emit('process');
ee.emit('close');