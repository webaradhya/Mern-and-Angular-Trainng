var crypto = require('crypto'),
    fs = require('fs'),
    key = 'mysecret key'

// open file stream
var fstream = fs.createReadStream('Hands-on-3\\text1_file.txt');
var hash = crypto.createHash('sha512', key);
hash.setEncoding('hex');

// once the stream is done, we read the values
fstream.on('end', function() {
    hash.end();
    // print result
    console.log(hash.read());
});

fstream.pipe(hash);