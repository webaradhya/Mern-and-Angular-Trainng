var fs = require("fs");

// Create a readable stream
var readerStream = fs.createReadStream('Hands-on-3\\text1_file.txt');

// Create a writable stream
var writerStream = fs.createWriteStream('Hands-on-3\\text2_file.txt');
var writeStream = fs.createWriteStream('Hands-on-3\\text_file.txt');

// Pipe the read and write operations
// read input.txt and write data to output.txt
readerStream.pipe(writerStream);
readerStream.pipe(writeStream);

console.log("Program Ended");