/*Write program to read the contents of a file Synchronously and Asynchronously*/ 


//Reading content Synchronously
const fs = require('fs');
const data = fs.readFileSync('Hands-on-3\\text_file.txt',{encoding :'utf8', flag:'r'});
console.log(data);

//Reading content Asynchronously
fs.readFile('Hands-on-3\\text1_file.txt','utf-8',(err,data) =>{
    if(err){
        console.log(err);
        return;
    }
    else{
        console.log(data);
    }
})