var fs = require("fs");
var zlib = require('zlib');

// Compress the file input.txt to input.txt.gz
fs.createReadStream('Hands-on-3\\text1_file.txt')
   .pipe(zlib.createGzip())
   .pipe(fs.createWriteStream('Hands-on-3\\text1_file.txt.gz'));
  
console.log("File Compressed.");