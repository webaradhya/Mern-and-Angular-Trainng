var fs = require("fs");
var data = '';

// Create a readable stream
var readerStream = fs.createReadStream('Hands-on-3\\text1_file.txt');

// Set the encoding to be utf8. 
readerStream.setEncoding('UTF8');

// Handle stream events --> data, end, and error
readerStream.on('data', function(chunk) {
   data += chunk;
});

readerStream.on('end',function() {
   console.log(data);
});

readerStream.on('error', function(err) {
   console.log(err.stack);
});

console.log("Program Ended");

var content = fs.readFileSync("Hands-on-3\\text1_file.txt",{encoding:'utf8'});
function countVowel(str) { 

    // find the count of vowels and consonants
    var vowels = str.match(/[aeiou]/gi).length;
    var consonants = str.match(/[^aeiou]/gi).length; 

    //percentage of vowels 
    var total = str.length;
    var percent_vowels = (vowels/total)*100;
    percent_vowels = percent_vowels.toFixed(2);
    //Percentage of Consonants
    var percent_consonant = (consonants/total)*100;
    percent_consonant = percent_consonant.toFixed(2);

    // return number of vowels,Consonants and Percentile
    console.log('No. of Vowels: ',vowels);
    console.log('No. of Consonants: ',consonants);
    console.log('Percentage of Vowels is: ', percent_vowels);
    console.log('Percentage of Consonant is: ', percent_consonant);
}
countVowel(content);
