/*Write program to write the contents of a file Synchronously and Asynchronously*/ 
 

//Write the contents of a File Synchronously
const fs = require('fs');
const content = ' I am Aradhya Rathore, clanFellow at Blazeclan Technologies';
fs.writeFileSync("Hands-on-3\\text_file.txt",content);
console.log('Written Content is: ',fs.readFileSync("Hands-on-3\\text_file.txt", "utf8"));


//Write the contents of a File Asynchronously
fs.writeFile('Hands-on-3\\text1_file.txt', 'Hello World!', function (err) { 
                        if (err)
        console.log(err);
                        else
        console.log('Written Content is: ', fs.readFileSync("Hands-on-3\\text1_file.txt", "utf8"));
});

//Write the contents of a file Asynchronously without deleting previous one
fs.appendFile('Hands-on-3\\text1_file.txt',content,function(err){
    if(err){
        console.log(err);
    }
    else{
        console.log('Written Content is: ', fs.readFileSync("Hands-on-3\\text1_file.txt", "utf8"));  
    }
});