const path = require('path');
const filename = 'Hands-on-3\\text_file.txt';
dir_name = path.dirname(filename);
base_name = path.basename(filename);
ext_name = path.extname(filename);
console.log('Directory Name:', dir_name);
console.log('Base Name of File:', base_name);
console.log('Extension of File:', ext_name);