var os = require('os');
console.log("OS: ", os.platform());
console.log("Hostname: ", os.hostname());
console.log('OS No. :',os.release());