const local = require ('repl');

local.start ('$ ');