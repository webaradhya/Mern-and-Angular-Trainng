console.log("\x1b[33m%s\x1b[0m", "I am in yellow color");


