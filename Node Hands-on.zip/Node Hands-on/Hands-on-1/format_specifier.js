const num = Number(14);

console.log("Using format specifiers....");
console.log("My %s has %d ears", "cat", 2);
console.log("My favourite number is : %o", num);
