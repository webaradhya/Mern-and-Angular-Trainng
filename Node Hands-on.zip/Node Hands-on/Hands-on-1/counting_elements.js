const x =14 ;

console.count ('The value x is ' + x + ' and has been checked..How many times?')