const console = require("console");

console.trace("Testing....");

console.trace("No of Clanmates: %d", 17);