const config = {
    host: "localhost",
    user: "root@localhost",
    password: "Namokar@72",
    database: "hr_db",
  };
  
  module.exports = config;